﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class frm_passc : Form
    {
        public frm_passc()
        {
            InitializeComponent();
        }

        private void frm_passc_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbCommand cmd = new OleDbCommand("select * from login where id='" + textBox1.Text + "'", Class1.con);
            OleDbDataReader dr;
            dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows == true)
            {
                if (dr["password"].ToString() != textBox2.Text)
                {
                    MessageBox.Show("Password Not Matched!");
                    textBox2.Focus();
                }
                else
                {
                    MessageBox.Show("successfuly changed password");
                     OleDbCommand cmd1 = new OleDbCommand("update into login values set password='" + textBox3.Text + "' where id=('"+ textBox1.Text +"') ", Class1.con);
                     cmd1.ExecuteNonQuery();
                                                              

                }
           }
            else
                MessageBox.Show("Invalid User id");
            textBox1.Focus();
            dr.Close();
        }

        }
    }


