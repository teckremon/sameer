﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class frm_sale : Form
    {
        public frm_sale()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            frm_party pr = new frm_party();
            pr.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //dataGridView1.Rows.Add(textBox1.Text,textBox2.Text , textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text, textBox10.Text, textBox11.Text, textBox12.Text, textBox13.Text, textBox14.Text, textBox15.Text, comboBox1.Text, comboBox2.Text, dateTimePicker1.Text);
        }

        private void frm_sale_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter da1 = new OleDbDataAdapter("select item_code from m_item ", Class1.con);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds1.Tables[0].Rows.Count; j++)
                {
                    comboBox2.Items.Add((ds1.Tables[0].Rows[j]["item_code"]));
                }
            }

            OleDbDataAdapter da = new OleDbDataAdapter("select cust_id from m_party ", Class1.con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds.Tables[0].Rows.Count; j++)
                {
                    comboBox1.Items.Add((ds.Tables[0].Rows[j]["cust_id"]));
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            OleDbDataAdapter da2 = new OleDbDataAdapter("select * from item_stock where item_code='" + comboBox2.SelectedItem + "' ", Class1.con);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            if (ds2.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds2.Tables[0].Rows.Count; j++)
                {
                    textBox5.Text = ds2.Tables[0].Rows[j]["item_comp"].ToString();
                    textBox13.Text = ds2.Tables[0].Rows[j]["item_cat"].ToString();
                    textBox6.Text = ds2.Tables[0].Rows[j]["batch_no"].ToString();
                    textBox14.Text = ds2.Tables[0].Rows[j]["manu_date"].ToString();
                    textBox15.Text = ds2.Tables[0].Rows[j]["exp_date"].ToString();
                    textBox9.Text = ds2.Tables[0].Rows[j]["price"].ToString();
                    textBox3.Text = ds2.Tables[0].Rows[j]["qty"].ToString();
                }
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
     OleDbCommand cmd = new OleDbCommand("insert into sale_trans(invoice,pa_id,amount,date) values('" + textBox1.Text + "' ,'" + comboBox1.SelectedItem + "','" + textBox2.Text + "','" + dateTimePicker1.Value + "')", Class1.con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Item add Successfully");
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
    }
}
