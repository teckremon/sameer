﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class frmlgn : Form
    {
        OleDbCommand cmd;
        
        public frmlgn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            cmd = new OleDbCommand("select * from login where id='" + textBox1.Text + "'", Class1.con);
            OleDbDataReader dr;
            dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows == true)
            {
                if (dr["password"].ToString() != textBox2.Text)
                {
                    MessageBox.Show("Password Not Matched!");
                    textBox2.Focus();
                }
                else
                {
                    MessageBox.Show("successfuly login");
                    this.Close();
                    MDIParent2 mdi=new MDIParent2();
                    
                                                       

                }
                }
            else
                MessageBox.Show("Invalid User id");
            dr.Close();
        }

        private void frmlgn_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
