﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class frm_pur : Form
    {
        public frm_pur()
        {
            InitializeComponent();
        }

               private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
            OleDbDataAdapter da = new OleDbDataAdapter("select co_id from m_comp ", Class1.con);
            DataSet ds = new DataSet();
            da.Fill(ds);
             
            if (ds.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds.Tables[0].Rows.Count; j++)
                {
                    comboBox3.Items.Add((ds.Tables[0].Rows[j]["co_id"]));
                }
            }
            OleDbDataAdapter da1 = new OleDbDataAdapter("select item_code from m_item ", Class1.con);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds1.Tables[0].Rows.Count; j++)
                {
                    comboBox2.Items.Add((ds1.Tables[0].Rows[j]["item_code"]));
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            mst_med med = new mst_med();
            med.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            frm_comp fc= new frm_comp ();
            fc.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
         //dataGridView1.Rows.Add(textBox1.Text, textBox2.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text, textBox10.Text, textBox11.Text, textBox12.Text, textBox13.Text, textBox14.Text,comboBox1.Text, comboBox2.Text, dateTimePicker1.Text);
       
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            OleDbDataAdapter da2 = new OleDbDataAdapter("select * from item_stock where item_code='" + comboBox2.SelectedItem + "' ", Class1.con);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            if (ds2.Tables[0].Rows.Count > 0)
            {
                int j = 0;
                for (j = 0; j < ds2.Tables[0].Rows.Count; j++)
                {
                    textBox13.Text = ds2.Tables[0].Rows[j]["item_name"].ToString();
                    textBox14.Text = ds2.Tables[0].Rows[j]["item_cat"].ToString();
                    textBox1.Text = ds2.Tables[0].Rows[j]["qty"].ToString();

                }
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbCommand cmd = new OleDbCommand("insert into pur_trans(invoice,co_id,amount,date) values('" + textBox5.Text  + "' ,'" + comboBox3.SelectedItem + "','" + textBox2.Text + "','" + dateTimePicker4.Value  + "')", Class1.con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Item add Successfully");
        }
                        }

       
        
    }
