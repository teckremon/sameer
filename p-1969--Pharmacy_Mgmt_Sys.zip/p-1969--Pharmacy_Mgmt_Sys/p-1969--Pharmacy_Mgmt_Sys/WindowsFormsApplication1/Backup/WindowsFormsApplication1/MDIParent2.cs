﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class MDIParent2 : Form
    {
        private int childFormNumber = 0;

        public MDIParent2()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void MDIParent2_Load(object sender, EventArgs e)
        {
            Class1.Connection();
            menu.Enabled = true;
            frmlgn frm1 = new frmlgn();
            frm1.ShowDialog();
        }

        private void toolsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void purchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_pur pr = new frm_pur();
            pr.Show();
        }

        private void addMedicineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mst_med m = new mst_med();
            m.Show();
        }

        private void aDDPartyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_party p = new frm_party();
            p.Show();

        }

        private void addCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_comp c = new frm_comp();
            c.Show();
        }

        private void userAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_passc ps = new frm_passc();
            ps.Show();
        }

        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_sale sl = new frm_sale();
            sl.Show();
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void companyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchcom sc=new searchcom();
            sc.Show();
        }

        private void medicineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchmed sm=new searchmed() ;
            sm.Show();

        }

        private void partyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchpar sp=new searchpar();
            sp.Show();
        }

        private void purchaseReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void stockDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            det_stock ds = new det_stock();
            ds.Show();

        }

        private void purchaseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            det_pur dp = new det_pur();
            dp.Show();
        }

        private void salesDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            det_sale dl = new det_sale();
            dl.Show();
        }

       
    }
}
