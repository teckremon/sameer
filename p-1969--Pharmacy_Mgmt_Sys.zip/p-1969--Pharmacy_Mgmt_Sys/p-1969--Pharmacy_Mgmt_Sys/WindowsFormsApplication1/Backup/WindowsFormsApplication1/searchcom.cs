﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class searchcom : Form
    {
        OleDbDataAdapter da;
        DataSet ds;
        DataView view;
        string str;
        public searchcom()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            da = new OleDbDataAdapter("select * from m_comp", Class1.con);
            ds = new DataSet();
            da.Fill(ds, "m_comp");
            view = new DataView(ds.Tables["m_comp"]);
            str= textBox1.Text;
            view.RowFilter = "co_name like '" + str + "%' ";
            dataGridView1.DataSource = view;

        }

        private void searchcom_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'db1DataSet.m_comp' table. You can move, or remove it, as needed.
            this.m_compTableAdapter.Fill(this.db1DataSet.m_comp);
            // TODO: This line of code loads data into the 'db1DataSet.login' table. You can move, or remove it, as needed.
            //this.loginTableAdapter.Fill(this.db1DataSet.login);
            da = new OleDbDataAdapter("select * from m_comp", Class1.con);
            ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
