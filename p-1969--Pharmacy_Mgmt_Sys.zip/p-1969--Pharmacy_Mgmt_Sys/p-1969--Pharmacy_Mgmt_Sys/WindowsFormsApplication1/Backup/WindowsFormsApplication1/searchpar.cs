﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class searchpar : Form
    {
        OleDbDataAdapter da;
        DataSet ds;
        DataView view;
        string str;

        public searchpar()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            da = new OleDbDataAdapter("select * from m_party", Class1.con);
            ds = new DataSet();
            da.Fill(ds, "m_party");
            view = new DataView(ds.Tables["m_party"]);
            str = textBox1.Text;
            view.RowFilter = "party_name like '" + str + "%' ";
            dataGridView1.DataSource = view;
        
        }

        private void searchpar_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
