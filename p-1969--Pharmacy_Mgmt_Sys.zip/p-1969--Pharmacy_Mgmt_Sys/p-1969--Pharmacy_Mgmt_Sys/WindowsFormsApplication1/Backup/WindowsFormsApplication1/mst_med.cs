﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class mst_med : Form
    {
        OleDbCommand cmd;
        public mst_med()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
                 cmd = new OleDbCommand("insert into m_item(item_code,item_cat,item_name,item_comp) values('" + txtCode.Text + "' ,'" + textBox3.Text + "','" + textBox1.Text + "','" + textBox2.Text + "')", Class1.con);
         cmd.ExecuteNonQuery();
         MessageBox.Show("Item add Successfully");
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
