﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class frm_party : Form
    {
        OleDbCommand cmd;
        public frm_party()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("insert into m_party values('" + textBox1.Text + "','" + textBox2.Text + "','" + txtAddress.Text + "','" + txtcontactno.Text + "')", Class1.con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("data is saved");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new OleDbCommand("delete from m_party values where co_id=('" + textBox1.Text + "')", Class1.con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("data is deleted");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
            
                cmd = new OleDbCommand("update m_party values set co_name='" + textBox2.Text + "',add='" + txtAddress.Text + "',contact='" + txtcontactno.Text + "' where co_id=('"+ textBox1.Text +"')", Class1.con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("data is updated");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            txtAddress.Text = "";
            txtcontactno.Text = "";

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        

        }
    }

