﻿namespace PHARMACY
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sevenButton1 = new System.Windows.Forms.Button();
            this.eightButton2 = new System.Windows.Forms.Button();
            this.nineButton3 = new System.Windows.Forms.Button();
            this.divideButton4 = new System.Windows.Forms.Button();
            this.cancelEntryButton5 = new System.Windows.Forms.Button();
            this.cancelButton6 = new System.Windows.Forms.Button();
            this.multiplyButton7 = new System.Windows.Forms.Button();
            this.sixButton8 = new System.Windows.Forms.Button();
            this.fiveButton9 = new System.Windows.Forms.Button();
            this.fourButton10 = new System.Windows.Forms.Button();
            this.equalsButton11 = new System.Windows.Forms.Button();
            this.minusButton12 = new System.Windows.Forms.Button();
            this.threeButton13 = new System.Windows.Forms.Button();
            this.twoButton14 = new System.Windows.Forms.Button();
            this.oneButton15 = new System.Windows.Forms.Button();
            this.addButton17 = new System.Windows.Forms.Button();
            this.dotButton18 = new System.Windows.Forms.Button();
            this.zeroButton20 = new System.Windows.Forms.Button();
            this.resultsTextBox = new System.Windows.Forms.TextBox();
            this.displayResults = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // sevenButton1
            // 
            this.sevenButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenButton1.Location = new System.Drawing.Point(31, 127);
            this.sevenButton1.Name = "sevenButton1";
            this.sevenButton1.Size = new System.Drawing.Size(75, 43);
            this.sevenButton1.TabIndex = 0;
            this.sevenButton1.Text = "7";
            this.sevenButton1.UseVisualStyleBackColor = true;
            this.sevenButton1.Click += new System.EventHandler(this.button_click);
            // 
            // eightButton2
            // 
            this.eightButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightButton2.Location = new System.Drawing.Point(112, 127);
            this.eightButton2.Name = "eightButton2";
            this.eightButton2.Size = new System.Drawing.Size(75, 43);
            this.eightButton2.TabIndex = 1;
            this.eightButton2.Text = "8";
            this.eightButton2.UseVisualStyleBackColor = true;
            this.eightButton2.Click += new System.EventHandler(this.button_click);
            // 
            // nineButton3
            // 
            this.nineButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineButton3.Location = new System.Drawing.Point(193, 127);
            this.nineButton3.Name = "nineButton3";
            this.nineButton3.Size = new System.Drawing.Size(75, 43);
            this.nineButton3.TabIndex = 2;
            this.nineButton3.Text = "9";
            this.nineButton3.UseVisualStyleBackColor = true;
            this.nineButton3.Click += new System.EventHandler(this.button_click);
            // 
            // divideButton4
            // 
            this.divideButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divideButton4.Location = new System.Drawing.Point(274, 127);
            this.divideButton4.Name = "divideButton4";
            this.divideButton4.Size = new System.Drawing.Size(75, 43);
            this.divideButton4.TabIndex = 3;
            this.divideButton4.Text = "/";
            this.divideButton4.UseVisualStyleBackColor = true;
            this.divideButton4.Click += new System.EventHandler(this.operator_click);
            // 
            // cancelEntryButton5
            // 
            this.cancelEntryButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelEntryButton5.Location = new System.Drawing.Point(355, 127);
            this.cancelEntryButton5.Name = "cancelEntryButton5";
            this.cancelEntryButton5.Size = new System.Drawing.Size(75, 43);
            this.cancelEntryButton5.TabIndex = 4;
            this.cancelEntryButton5.Text = "C E";
            this.cancelEntryButton5.UseVisualStyleBackColor = true;
            this.cancelEntryButton5.Click += new System.EventHandler(this.cancelEntryButton5_Click);
            // 
            // cancelButton6
            // 
            this.cancelButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton6.Location = new System.Drawing.Point(355, 207);
            this.cancelButton6.Name = "cancelButton6";
            this.cancelButton6.Size = new System.Drawing.Size(75, 61);
            this.cancelButton6.TabIndex = 9;
            this.cancelButton6.Text = "C";
            this.cancelButton6.UseVisualStyleBackColor = true;
            this.cancelButton6.Click += new System.EventHandler(this.cancelButton6_Click);
            // 
            // multiplyButton7
            // 
            this.multiplyButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiplyButton7.Location = new System.Drawing.Point(274, 207);
            this.multiplyButton7.Name = "multiplyButton7";
            this.multiplyButton7.Size = new System.Drawing.Size(75, 61);
            this.multiplyButton7.TabIndex = 8;
            this.multiplyButton7.Text = "*";
            this.multiplyButton7.UseVisualStyleBackColor = true;
            this.multiplyButton7.Click += new System.EventHandler(this.operator_click);
            // 
            // sixButton8
            // 
            this.sixButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixButton8.Location = new System.Drawing.Point(193, 207);
            this.sixButton8.Name = "sixButton8";
            this.sixButton8.Size = new System.Drawing.Size(75, 61);
            this.sixButton8.TabIndex = 7;
            this.sixButton8.Text = "6";
            this.sixButton8.UseVisualStyleBackColor = true;
            this.sixButton8.Click += new System.EventHandler(this.button_click);
            // 
            // fiveButton9
            // 
            this.fiveButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveButton9.Location = new System.Drawing.Point(112, 207);
            this.fiveButton9.Name = "fiveButton9";
            this.fiveButton9.Size = new System.Drawing.Size(75, 61);
            this.fiveButton9.TabIndex = 6;
            this.fiveButton9.Text = "5";
            this.fiveButton9.UseVisualStyleBackColor = true;
            this.fiveButton9.Click += new System.EventHandler(this.button_click);
            // 
            // fourButton10
            // 
            this.fourButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourButton10.Location = new System.Drawing.Point(31, 207);
            this.fourButton10.Name = "fourButton10";
            this.fourButton10.Size = new System.Drawing.Size(75, 61);
            this.fourButton10.TabIndex = 5;
            this.fourButton10.Text = "4";
            this.fourButton10.UseVisualStyleBackColor = true;
            this.fourButton10.Click += new System.EventHandler(this.button_click);
            // 
            // equalsButton11
            // 
            this.equalsButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.equalsButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalsButton11.Location = new System.Drawing.Point(355, 299);
            this.equalsButton11.Name = "equalsButton11";
            this.equalsButton11.Size = new System.Drawing.Size(75, 141);
            this.equalsButton11.TabIndex = 14;
            this.equalsButton11.Text = "=";
            this.equalsButton11.UseVisualStyleBackColor = false;
            this.equalsButton11.Click += new System.EventHandler(this.equalsButton11_Click);
            // 
            // minusButton12
            // 
            this.minusButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusButton12.Location = new System.Drawing.Point(274, 299);
            this.minusButton12.Name = "minusButton12";
            this.minusButton12.Size = new System.Drawing.Size(75, 61);
            this.minusButton12.TabIndex = 13;
            this.minusButton12.Text = "-";
            this.minusButton12.UseVisualStyleBackColor = true;
            this.minusButton12.Click += new System.EventHandler(this.operator_click);
            // 
            // threeButton13
            // 
            this.threeButton13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeButton13.Location = new System.Drawing.Point(193, 299);
            this.threeButton13.Name = "threeButton13";
            this.threeButton13.Size = new System.Drawing.Size(75, 61);
            this.threeButton13.TabIndex = 12;
            this.threeButton13.Text = "3";
            this.threeButton13.UseVisualStyleBackColor = true;
            this.threeButton13.Click += new System.EventHandler(this.button_click);
            // 
            // twoButton14
            // 
            this.twoButton14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoButton14.Location = new System.Drawing.Point(112, 299);
            this.twoButton14.Name = "twoButton14";
            this.twoButton14.Size = new System.Drawing.Size(75, 61);
            this.twoButton14.TabIndex = 11;
            this.twoButton14.Text = "2";
            this.twoButton14.UseVisualStyleBackColor = true;
            this.twoButton14.Click += new System.EventHandler(this.button_click);
            // 
            // oneButton15
            // 
            this.oneButton15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneButton15.Location = new System.Drawing.Point(31, 299);
            this.oneButton15.Name = "oneButton15";
            this.oneButton15.Size = new System.Drawing.Size(75, 61);
            this.oneButton15.TabIndex = 10;
            this.oneButton15.Text = "1";
            this.oneButton15.UseVisualStyleBackColor = true;
            this.oneButton15.Click += new System.EventHandler(this.button_click);
            // 
            // addButton17
            // 
            this.addButton17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton17.Location = new System.Drawing.Point(274, 394);
            this.addButton17.Name = "addButton17";
            this.addButton17.Size = new System.Drawing.Size(75, 46);
            this.addButton17.TabIndex = 18;
            this.addButton17.Text = "+";
            this.addButton17.UseVisualStyleBackColor = true;
            this.addButton17.Click += new System.EventHandler(this.operator_click);
            // 
            // dotButton18
            // 
            this.dotButton18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dotButton18.Location = new System.Drawing.Point(193, 394);
            this.dotButton18.Name = "dotButton18";
            this.dotButton18.Size = new System.Drawing.Size(75, 46);
            this.dotButton18.TabIndex = 17;
            this.dotButton18.Text = ".";
            this.dotButton18.UseVisualStyleBackColor = true;
            this.dotButton18.Click += new System.EventHandler(this.button_click);
            // 
            // zeroButton20
            // 
            this.zeroButton20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zeroButton20.Location = new System.Drawing.Point(31, 394);
            this.zeroButton20.Name = "zeroButton20";
            this.zeroButton20.Size = new System.Drawing.Size(156, 46);
            this.zeroButton20.TabIndex = 15;
            this.zeroButton20.Text = "0";
            this.zeroButton20.UseVisualStyleBackColor = true;
            this.zeroButton20.Click += new System.EventHandler(this.button_click);
            // 
            // resultsTextBox
            // 
            this.resultsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultsTextBox.Location = new System.Drawing.Point(31, 73);
            this.resultsTextBox.Name = "resultsTextBox";
            this.resultsTextBox.Size = new System.Drawing.Size(399, 38);
            this.resultsTextBox.TabIndex = 19;
            this.resultsTextBox.Text = "0";
            this.resultsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // displayResults
            // 
            this.displayResults.AutoSize = true;
            this.displayResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayResults.Location = new System.Drawing.Point(28, 23);
            this.displayResults.Name = "displayResults";
            this.displayResults.Size = new System.Drawing.Size(0, 31);
            this.displayResults.TabIndex = 20;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 452);
            this.Controls.Add(this.displayResults);
            this.Controls.Add(this.resultsTextBox);
            this.Controls.Add(this.addButton17);
            this.Controls.Add(this.dotButton18);
            this.Controls.Add(this.zeroButton20);
            this.Controls.Add(this.equalsButton11);
            this.Controls.Add(this.minusButton12);
            this.Controls.Add(this.threeButton13);
            this.Controls.Add(this.twoButton14);
            this.Controls.Add(this.oneButton15);
            this.Controls.Add(this.cancelButton6);
            this.Controls.Add(this.multiplyButton7);
            this.Controls.Add(this.sixButton8);
            this.Controls.Add(this.fiveButton9);
            this.Controls.Add(this.fourButton10);
            this.Controls.Add(this.cancelEntryButton5);
            this.Controls.Add(this.divideButton4);
            this.Controls.Add(this.nineButton3);
            this.Controls.Add(this.eightButton2);
            this.Controls.Add(this.sevenButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sevenButton1;
        private System.Windows.Forms.Button eightButton2;
        private System.Windows.Forms.Button nineButton3;
        private System.Windows.Forms.Button divideButton4;
        private System.Windows.Forms.Button cancelEntryButton5;
        private System.Windows.Forms.Button cancelButton6;
        private System.Windows.Forms.Button multiplyButton7;
        private System.Windows.Forms.Button sixButton8;
        private System.Windows.Forms.Button fiveButton9;
        private System.Windows.Forms.Button fourButton10;
        private System.Windows.Forms.Button equalsButton11;
        private System.Windows.Forms.Button minusButton12;
        private System.Windows.Forms.Button threeButton13;
        private System.Windows.Forms.Button twoButton14;
        private System.Windows.Forms.Button oneButton15;
        private System.Windows.Forms.Button addButton17;
        private System.Windows.Forms.Button dotButton18;
        private System.Windows.Forms.Button zeroButton20;
        private System.Windows.Forms.TextBox resultsTextBox;
        private System.Windows.Forms.Label displayResults;
    }
}